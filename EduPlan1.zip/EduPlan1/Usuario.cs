﻿
using Supabase.Postgrest.Attributes;
using Supabase.Postgrest.Models;
using System;
using Supabase;
using Supabase.Postgrest;
using Supabase.Postgrest.Models;


[Table("usuarios")]
public class Usuario : BaseModel
{
    [PrimaryKey("id")]
    public Guid Id { get; set; }

    [Column("correo")]
    public string Correo { get; set; }

    [Column("contrasena")]
    public string Contrasena { get; set; }
}

