﻿using Supabase;
using Supabase.Postgrest;
using Supabase.Postgrest.Models;
using System.Windows;

namespace EduPlan1
{
    public partial class MainWindow : Window
    {
        private Supabase.Client client;  // Cliente global
        
        public MainWindow()
        {

            InitializeComponent();

            var options = new SupabaseOptions
            {
                AutoConnectRealtime = false
            };

            client = new Supabase.Client(
                "https://kbisosxvewqueregzfui.supabase.co",
                "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtiaXNvc3h2ZXdxdWVyZWd6ZnVpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjMyMDc5MDksImV4cCI6MjA3ODc4MzkwOX0.Mvvyn3Kcz72C4z8dko0btNYm2C3vUKtLi0D_qjAxLbs",
                options
            );
        }

        private async void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            string correo = txtCorreo.Text.Trim();
            string pass = txtPassword.Password.Trim();

            var result = await client
                .From<Usuario>()
                .Where(u => u.Correo == correo && u.Contrasena == pass)
                .Get();

            if (result.Models.Count > 0)
            {
                MessageBox.Show("Bienvenido");
            }
            else
            {
                MessageBox.Show("Correo o contraseña incorrectos.");
            }
        }
    }
}
