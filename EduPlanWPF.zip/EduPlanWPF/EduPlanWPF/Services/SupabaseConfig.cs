﻿namespace EduPlanWPF.Services
{
    public static class SupabaseConfig
    {
        public const string SupabaseUrl = "https://nnxsrtpixbxttimhuthh.supabase.co";
        public const string SupabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5ueHNydHBpeGJ4dHRpbWh1dGhoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjUzODk0NzgsImV4cCI6MjA4MDk2NTQ3OH0.CgwHKjcIfnz3GumzvGo7Z07GAiXA5c_zoH6i947wSCg";
    }
}
