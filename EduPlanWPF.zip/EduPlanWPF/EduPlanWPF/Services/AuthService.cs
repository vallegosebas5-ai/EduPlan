﻿using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using EduPlanWPF.Models;
using Newtonsoft.Json;

namespace EduPlanWPF.Services
{
    public class AuthService
    {
        private readonly HttpClient _client;

        public AuthService()
        {
            _client = new HttpClient();
            _client.DefaultRequestHeaders.Clear();
            _client.DefaultRequestHeaders.Add("apikey", SupabaseConfig.SupabaseAnonKey);
            _client.DefaultRequestHeaders.Add("Authorization", $"Bearer {SupabaseConfig.SupabaseAnonKey}");
        }

        // ====================================================
        //  REGISTRO
        // ====================================================
        public async Task<(bool success, string error)> RegisterAsync(string email, string password, string fullName)
        {
            try
            {
                var payload = new
                {
                    email = email,
                    password = password,
                    data = new
                    {
                        full_name = fullName
                    }
                };

                var json = JsonConvert.SerializeObject(payload);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                var url = $"{SupabaseConfig.SupabaseUrl}/auth/v1/signup";

                var response = await _client.PostAsync(url, content);

                if (response.IsSuccessStatusCode)
                    return (true, null);

                var body = await response.Content.ReadAsStringAsync();
                return (false, body);
            }
            catch (Exception ex)
            {
                return (false, $"Excepción: {ex.Message}");
            }
        }

        // ====================================================
        //  LOGIN
        // ====================================================
        public async Task<string> LoginAsync(string email, string password)
        {
            try
            {
                var payload = new
                {
                    email = email,
                    password = password
                };

                var json = JsonConvert.SerializeObject(payload);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                var url = $"{SupabaseConfig.SupabaseUrl}/auth/v1/token?grant_type=password";

                var response = await _client.PostAsync(url, content);
                var body = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                    return null;

                dynamic data = JsonConvert.DeserializeObject(body);
                return data?.access_token;
            }
            catch
            {
                return null;
            }
        }
    }
}
