﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using EduPlanWPF.Models;

namespace EduPlanWPF.Helpers
{
    public static class SessionManager
    {
        public static string Token { get; set; }
        public static UserModel CurrentUser { get; set; }
    }
}

