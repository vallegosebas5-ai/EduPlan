﻿using EduPlanWPF.Models;
using System.Collections.Generic;
using System.Linq;

namespace EduPlanWPF.Helpers
{
    public static class GoalProgressHelper
    {
        public static int CalculateProgress(IEnumerable<TaskModel> tasks)
        {
            var list = tasks.ToList();
            if (!list.Any())
                return 0;

            int completed = list.Count(t => t.Status == "completed");
            return (int)((completed / (double)list.Count) * 100);
        }
    }
}
