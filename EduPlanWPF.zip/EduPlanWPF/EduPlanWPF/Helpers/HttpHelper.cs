﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Net.Http.Headers;

namespace EduPlanWPF.Helpers
{
    public static class HttpHelper
    {
        public static HttpClient GetClient(string token = null)
        {
            var client = new HttpClient();
            client.DefaultRequestHeaders.Add("apikey", Services.SupabaseConfig.SupabaseAnonKey);

            if (!string.IsNullOrEmpty(token))
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            }

            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            return client;
        }
    }
}


