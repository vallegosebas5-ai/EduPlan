﻿using EduPlanWPF.Helpers;
using EduPlanWPF.Services;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;

namespace EduPlanWPF.ViewModels
{
    public class RegisterViewModel : INotifyPropertyChanged
    {
        public string FullName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string RepeatPassword { get; set; }

        private string _errorMessage;
        public string ErrorMessage
        {
            get => _errorMessage;
            set { _errorMessage = value; OnPropertyChanged(); }
        }

        public ICommand RegisterCommand { get; set; }

        private readonly AuthService _authService;

        public RegisterViewModel()
        {
            _authService = new AuthService();

            RegisterCommand = new RelayCommand(async o =>
            {
                if (Password != RepeatPassword)
                {
                    ErrorMessage = "Las contraseñas no coinciden";
                    return;
                }

                var result = await _authService.RegisterAsync(Email, Password, FullName);

                if (result.success)
                {
                    MessageBox.Show("Cuenta creada exitosamente", "Éxito",
                        MessageBoxButton.OK, MessageBoxImage.Information);

                    LoginWindow login = new LoginWindow();
                    login.Show();
                    Application.Current.Windows[0].Close();
                }
                else
                {
                    ErrorMessage = result.error;
                }
            });
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string name = null) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
