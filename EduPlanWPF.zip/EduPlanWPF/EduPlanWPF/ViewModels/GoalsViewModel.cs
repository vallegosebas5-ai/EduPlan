﻿using EduPlanWPF.Helpers;
using EduPlanWPF.Models;
using EduPlanWPF.Services;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows;

namespace EduPlanWPF.ViewModels
{
    public class GoalsViewModel : INotifyPropertyChanged
    {
        private readonly GoalService _goalService;

        public ObservableCollection<GoalModel> Goals { get; } =
            new ObservableCollection<GoalModel>();

        public AsyncRelayCommand AddGoalCommand { get; }

        private string _newGoalTitle;
        public string NewGoalTitle
        {
            get => _newGoalTitle;
            set { _newGoalTitle = value; OnPropertyChanged(); }
        }

        public GoalsViewModel()
        {
            _goalService = new GoalService();

            AddGoalCommand = new AsyncRelayCommand(_ => AddGoal());

            _ = LoadGoalsAsync();
        }

        // =============================
        // CARGAR METAS
        // =============================
        private async Task LoadGoalsAsync()
        {
            try
            {
                var list = await _goalService.GetGoals(
                    Session.Token,
                    Session.UserId     // 🔥 UUID
                );

                Goals.Clear();
                foreach (var goal in list)
                    Goals.Add(goal);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error cargando metas:\n{ex.Message}");
            }
        }

        // =============================
        // AGREGAR META
        // =============================
        private async Task AddGoal()
        {
            if (string.IsNullOrWhiteSpace(NewGoalTitle))
                return;

            var goal = new GoalModel
            {
                UserId = Session.UserId,
                Title = NewGoalTitle,
                Progress = 0,
                CreatedAt = DateTime.UtcNow
            };

            try
            {
                var ok = await _goalService.AddGoal(Session.Token, goal);

                if (!ok)
                {
                    MessageBox.Show("Supabase rechazó la meta");
                    return;
                }

                await LoadGoalsAsync();
                NewGoalTitle = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error creando meta:\n{ex.Message}");
            }
        }

        // =============================
        // INotifyPropertyChanged
        // =============================
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string name = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}