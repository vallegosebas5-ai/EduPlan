﻿using EduPlanWPF.Models;
using EduPlanWPF.Services;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace EduPlanWPF.ViewModels
{
    public class CalendarViewModel : INotifyPropertyChanged
    {
        private readonly TaskService _taskService;
        private readonly GoalService _goalService;

        public ObservableCollection<TaskModel> DayTasks { get; } =
            new ObservableCollection<TaskModel>();

        public ObservableCollection<GoalModel> DayGoals { get; } =
            new ObservableCollection<GoalModel>();

        private DateTime _selectedDate = DateTime.Today;
        public DateTime SelectedDate
        {
            get => _selectedDate;
            set
            {
                _selectedDate = value;
                OnPropertyChanged();
                _ = LoadDayDataAsync();
            }
        }

        public CalendarViewModel()
        {
            _taskService = new TaskService();
            _goalService = new GoalService();

            _ = LoadDayDataAsync();
        }

        // =============================
        // CARGAR TAREAS + METAS DEL DÍA
        // =============================
        private async Task LoadDayDataAsync()
        {
            DayTasks.Clear();
            DayGoals.Clear();

            var tasks = await _taskService.GetTasks(Session.Token, Session.UserId);
            var goals = await _goalService.GetGoals(Session.Token, Session.UserId);

            foreach (var task in tasks.Where(t => t.DueDate?.Date == SelectedDate.Date))
                DayTasks.Add(task);

            foreach (var goal in goals.Where(g => g.EndDate?.Date == SelectedDate.Date))
                DayGoals.Add(goal);
        }

        // =============================
        // INotifyPropertyChanged
        // =============================
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string name = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
