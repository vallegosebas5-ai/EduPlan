﻿using EduPlanWPF.Models;
using EduPlanWPF.Services;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace EduPlanWPF.ViewModels
{
    public class StatsViewModel : INotifyPropertyChanged
    {
        private readonly TaskService _taskService;
        private readonly GoalService _goalService;

        private int _totalTasks;
        public int TotalTasks
        {
            get => _totalTasks;
            set { _totalTasks = value; OnPropertyChanged(); }
        }

        private int _completedTasks;
        public int CompletedTasks
        {
            get => _completedTasks;
            set { _completedTasks = value; OnPropertyChanged(); }
        }

        private int _taskCompletionPercent;
        public int TaskCompletionPercent
        {
            get => _taskCompletionPercent;
            set { _taskCompletionPercent = value; OnPropertyChanged(); }
        }

        private int _averageGoalProgress;
        public int AverageGoalProgress
        {
            get => _averageGoalProgress;
            set { _averageGoalProgress = value; OnPropertyChanged(); }
        }

        public StatsViewModel()
        {
            _taskService = new TaskService();
            _goalService = new GoalService();

            _ = LoadStatsAsync();
        }

        // =============================
        // CARGAR ESTADÍSTICAS
        // =============================
        private async Task LoadStatsAsync()
        {
            var tasks = await _taskService.GetTasks(
                Session.Token,
                Session.UserId);

            var goals = await _goalService.GetGoals(
                Session.Token,
                Session.UserId);

            CalculateTaskStats(tasks);
            CalculateGoalStats(goals);
        }

        // =============================
        // TAREAS
        // =============================
        private void CalculateTaskStats(List<TaskModel> tasks)
        {
            TotalTasks = tasks.Count;
            CompletedTasks = tasks.Count(t => t.Status == "completed");

            TaskCompletionPercent = TotalTasks == 0
                ? 0
                : (CompletedTasks * 100) / TotalTasks;
        }

        // =============================
        // METAS
        // =============================
        private void CalculateGoalStats(List<GoalModel> goals)
        {
            if (!goals.Any())
            {
                AverageGoalProgress = 0;
                return;
            }

            AverageGoalProgress = (int)goals.Average(g => g.Progress);
        }

        // =============================
        // INotifyPropertyChanged
        // =============================
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string name = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
