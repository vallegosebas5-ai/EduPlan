﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EduPlanWPF.Helpers;
using EduPlanWPF.Services;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;

namespace EduPlanWPF.ViewModels
{
    public class LoginViewModel : INotifyPropertyChanged
    {
        private string _email;
        private string _password;
        private readonly AuthService _authService;

        public event PropertyChangedEventHandler PropertyChanged;

        public string Email
        {
            get => _email;
            set { _email = value; OnPropertyChanged(); }
        }

        public string Password
        {
            get => _password;
            set { _password = value; OnPropertyChanged(); }
        }

        public RelayCommand LoginCommand { get; }

        public LoginViewModel()
        {
            _authService = new AuthService();

            LoginCommand = new RelayCommand(async (obj) =>
            {
                try
                {
                    var token = await _authService.LoginAsync(Email, Password);

                    if (token == null)
                    {
                        MessageBox.Show("Credenciales incorrectas");
                        return;
                    }

                    // Guardamos el Token
                    Session.Token = token;
                    Session.Email = Email;

                    // Abrir ventana principal
                    var main = new MainWindow();
                    main.Show();

                    // Cerrar login
                    foreach (Window win in Application.Current.Windows)
                    {
                        if (win is LoginWindow)
                        {
                            win.Close();
                            break;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error en el login:\n" + ex.Message);
                }
            });
        }

        private void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
