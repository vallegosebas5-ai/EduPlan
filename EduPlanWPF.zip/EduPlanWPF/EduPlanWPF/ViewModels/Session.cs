﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EduPlanWPF
{
    public static class Session
    {
        public static string Token { get; set; }
        public static string Email { get; set; }
        public static string UserId { get; set; } // opcional si lo usas
    }
}
