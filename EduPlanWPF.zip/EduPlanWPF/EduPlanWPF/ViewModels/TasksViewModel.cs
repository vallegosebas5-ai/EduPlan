﻿using EduPlanWPF.Helpers;
using EduPlanWPF.Models;
using EduPlanWPF.Services;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows;

namespace EduPlanWPF.ViewModels
{
    public class TasksViewModel : INotifyPropertyChanged
    {
        private readonly TaskService _taskService;
        private readonly GoalService _goalService;


        public ObservableCollection<TaskModel> Tasks { get; } =
            new ObservableCollection<TaskModel>();

        public RelayCommand AddTaskCommand { get; }
        public RelayCommand DeleteTaskCommand { get; }
        public RelayCommand ToggleStatusCommand { get; }

        private string _newTaskTitle;
        public string NewTaskTitle
        {
            get => _newTaskTitle;
            set { _newTaskTitle = value; OnPropertyChanged(); }
        }

        private bool _isLoading;
        public bool IsLoading
        {
            get => _isLoading;
            set { _isLoading = value; OnPropertyChanged(); }
        }

        public TasksViewModel()
        {
            _taskService = new TaskService();
            _goalService = new GoalService();


            AddTaskCommand = new RelayCommand(async _ => await AddTask());
            DeleteTaskCommand = new RelayCommand(async t => await DeleteTask(t as TaskModel));
            ToggleStatusCommand = new RelayCommand(async t => await ToggleStatus(t as TaskModel));

            _ = LoadTasksAsync();
        }

        // =============================
        // CARGAR TAREAS
        // =============================
        private async Task LoadTasksAsync()
        {
            try
            {
                IsLoading = true;

                var list = await _taskService.GetTasks(
                    Session.Token,
                    Session.UserId       // 🔥 NO Email
                );

                Tasks.Clear();
                foreach (var task in list)
                    Tasks.Add(task);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error cargando tareas:\n{ex.Message}");
            }
            finally
            {
                IsLoading = false;
            }
        }

        // =============================
        // AGREGAR TAREA
        // =============================
        private async Task AddTask()
        {
            if (string.IsNullOrWhiteSpace(NewTaskTitle))
            {
                MessageBox.Show("Escribe un título");
                return;
            }

            var task = new TaskModel
            {
                Id = Guid.NewGuid(),
                UserId = Session.UserId,
                Title = NewTaskTitle,
                Status = "pending",
                CreatedAt = DateTime.UtcNow
            };

            try
            {
                var ok = await _taskService.AddTask(Session.Token, task);

                if (ok)
                {
                    Tasks.Add(task);
                    NewTaskTitle = "";
                }
                else
                {
                    MessageBox.Show("No se pudo crear la tarea");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al crear tarea:\n{ex.Message}");
            }
        }

        // =============================
        // ELIMINAR TAREA
        // =============================
        private async Task DeleteTask(TaskModel task)
        {
            if (task == null) return;

            if (MessageBox.Show(
                "¿Eliminar esta tarea?",
                "Confirmar",
                MessageBoxButton.YesNo) != MessageBoxResult.Yes)
                return;

            try
            {
                var ok = await _taskService.DeleteTask(Session.Token, task.Id);

                if (ok)
                    Tasks.Remove(task);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error eliminando tarea:\n{ex.Message}");
            }
        }

        // =============================
        // COMPLETAR / DESCOMPLETAR
        // =============================
        private async Task ToggleStatus(TaskModel task)
        {
            if (task == null) return;

            var newStatus = task.Status == "completed"
                ? "pending"
                : "completed";

            try
            {
                var ok = await _taskService.UpdateTask(
                    Session.Token,
                    task.Id,
                    new { status = newStatus });

                if (ok)
                    task.Status = newStatus;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error actualizando tarea:\n{ex.Message}");
            }
        }

        // =============================
        // INotifyPropertyChanged
        // =============================

        private async Task CompleteTaskAsync(TaskModel task)
        {
            await _taskService.UpdateTask(
                Session.Token,
                task.Id,
                new { status = "completed" });

            task.Status = "completed";

            if (task.GoalId.HasValue)
                await UpdateGoalProgressAsync(task.GoalId.Value);
        }

        private async Task UpdateGoalProgressAsync(Guid goalId)
        {
            var tasks = await _taskService.GetTasksByGoal(
                Session.Token,
                goalId);

            int progress = GoalProgressHelper.CalculateProgress(tasks);

            await _goalService.UpdateProgress(
                Session.Token,
                goalId,
                progress);
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string name = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
