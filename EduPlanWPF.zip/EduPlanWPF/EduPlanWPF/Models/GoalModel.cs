﻿using Newtonsoft.Json;
using System;

namespace EduPlanWPF.Models
{
    public class GoalModel
    {
        [JsonProperty("id")]
        public Guid Id { get; set; }

        [JsonProperty("user_id")]
        public string UserId { get; set; }

        [JsonProperty("title")]
        public string Title { get; set; }

        [JsonProperty("description")]
        public string Description { get; set; }

        [JsonProperty("start_date")]
        public DateTime? StartDate { get; set; }

        [JsonProperty("end_date")]
        public DateTime? EndDate { get; set; }

        [JsonProperty("progress")]
        public int Progress { get; set; } = 0;

        [JsonProperty("created_at")]
        public DateTime CreatedAt { get; set; }
    }
}