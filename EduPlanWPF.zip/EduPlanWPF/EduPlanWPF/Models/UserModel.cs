﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EduPlanWPF.Models
{
    public class UserModel
    {
        public string Id { get; set; }          // UUID de Supabase
        public string Email { get; set; }
        public string Password { get; set; }    // Solo para envío, nunca guardar en la app
    }
}
