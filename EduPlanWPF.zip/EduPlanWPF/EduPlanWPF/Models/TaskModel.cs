﻿using Newtonsoft.Json;
using System;

namespace EduPlanWPF.Models
{
    public class TaskModel
    {
        [JsonProperty("id")]
        public Guid Id { get; set; }

        [JsonProperty("user_id")]
        public string UserId { get; set; }

        [JsonProperty("goal_id")]
        public Guid? GoalId { get; set; }   // 🔥 CLAVE

        [JsonProperty("title")]
        public string Title { get; set; }

        [JsonProperty("description")]
        public string Description { get; set; }

        [JsonProperty("due_date")]
        public DateTime? DueDate { get; set; }

        [JsonProperty("status")]
        public string Status { get; set; } = "pending";

        [JsonProperty("created_at")]
        public DateTime CreatedAt { get; set; }

        // 👇 Útil para UI
        public bool IsCompleted => Status == "completed";
    }
}
