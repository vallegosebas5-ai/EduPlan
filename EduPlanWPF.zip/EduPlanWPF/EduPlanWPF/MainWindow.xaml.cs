﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EduPlanWPF.Views.Pages;


namespace EduPlanWPF
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            // Página inicial
            MainFrame.Content = new TasksPage();
        }

        private void Tasks_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Content = new TasksPage();
        }

        private void Goals_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Content = new GoalsPage();
        }

        private void Calendar_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Content = new CalendarPage();
        }

        private void Stats_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Content = new StatsPage();
        }
    }
}
